package com.sngular.captio.enums;

public enum MontoDotacionEnum {

	NACIONAL_COMIDA("Nacional", "Comida", 948), EXTRANJERO_COMIDA("Extranjero", "Comida", 1900),
	NACIONAL_ADICIONALES("Nacional", "Gastos adicionales a Comida, Hospedaje y Vuelos.", 215),
	EXTRANJERO_ADICIONALES("Extranjero", "Gastos adicionales a Comida, Hospedaje y Vuelos.", 330);

	private final String tipo;
	private final String concepto;
	private final double monto;

	MontoDotacionEnum(String tipo, String concepto, double monto) {
		this.tipo = tipo;
		this.concepto = concepto;
		this.monto = monto;
	}

	public String getTipo() {
		return tipo;
	}

	public String getConcepto() {
		return concepto;
	}

	public double getMonto() {
		return monto;
	}

	// Método auxiliar para buscar por tipo y concepto
	public static MontoDotacionEnum from(String tipo, String concepto) {
		for (MontoDotacionEnum v : values()) {
			if (v.tipo.equalsIgnoreCase(tipo) && v.concepto.equalsIgnoreCase(concepto)) {
				return v;
			}
		}
		throw new IllegalArgumentException("No existe viático para tipo=" + tipo + ", concepto=" + concepto);
	}

}
