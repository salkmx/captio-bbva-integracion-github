package com.sngular.captio.enums;

public enum CustomFieldsEnum {

	NOMBRE_INFORME(111), ID_VIAJE(108), ERRORES_INFORME_GASTOS(109), DESTINO_VIAJE_NACIONAL(79), CLAVE_USUARIO(112);

	private Integer idCustomField;

	public Integer getIdCustomField() {
		return idCustomField;
	}

	CustomFieldsEnum(Integer idCustomField) {
		this.idCustomField = idCustomField;
	}

}
